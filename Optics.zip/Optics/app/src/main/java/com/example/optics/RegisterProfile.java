package com.example.optics;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class RegisterProfile extends AppCompatActivity {

    EditText usernames, phoneNumber, passwords, confirmPasswords;
    Button Register;
    CheckBox checkMale, checkFemale, checkStaff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_profile);

        usernames = (EditText) findViewById(R.id.profileName);
        phoneNumber = (EditText) findViewById(R.id.cellNumber);
        passwords = (EditText) findViewById(R.id.password);
        confirmPasswords = (EditText) findViewById(R.id.confirm_password);
        Register = (Button) findViewById(R.id.register);
        checkMale = (CheckBox) findViewById(R.id.maleChecker);
        checkFemale = (CheckBox) findViewById(R.id.femaleChecker);
        checkStaff = (CheckBox) findViewById(R.id.Staff);


        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createUsers();
            }
        });

    }

            private void createUsers() {

                String storeName  = usernames.getText().toString();
                String storePhone  = phoneNumber.getText().toString();
                String storePasswords  = passwords.getText().toString();
                String storeConfirmPasswords  = passwords.getText().toString();


                //Check wether fields are empty and and verify passwords
                if (TextUtils.isEmpty(storeName)) {

                    Toast.makeText(RegisterProfile.this, "Username cannot be empty", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(storePhone)) {

                    Toast.makeText(RegisterProfile.this, "Phone cannot be empty", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(storePasswords)) {

                    Toast.makeText(RegisterProfile.this, "Password cannot be empty", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(storeConfirmPasswords)) {

                    Toast.makeText(RegisterProfile.this, "Password cannot be empty", Toast.LENGTH_SHORT).show();
                } else if (storePasswords.length() < 6) {

                    Toast.makeText(RegisterProfile.this, "Password length must be greater or equal to six", Toast.LENGTH_SHORT).show();
                } else if (storeConfirmPasswords.length() < 6) {

                    Toast.makeText(RegisterProfile.this, "Password length must be greater or equal to six", Toast.LENGTH_SHORT).show();
                } else if ((storePasswords).equals(storeConfirmPasswords)) {
                    Toast.makeText(RegisterProfile.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegisterProfile.this, Dashboard.class);
                    startActivity(intent);

                    verifyUser(storeName , storePhone , storePasswords);

                } else {
                    Toast.makeText(RegisterProfile.this, "Passwords don't match", Toast.LENGTH_SHORT).show();

                }

            }

    private void verifyUser(final String storeName, final String storePhone, final String storePasswords) {

        final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();

        RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

            if(!(dataSnapshot.child("Patients:").child(storePhone).exists())){

                HashMap <String , Object >userdata =  new HashMap<>();
                userdata.put("Username" , storeName  );
                userdata.put( "Password" , storePasswords );
                userdata.put( "Phone number" , storePhone);

                RootRef.child("Patients:").child(storePhone).updateChildren(userdata)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(RegisterProfile.this, ""+ storeName + " Has been registered succesfully", Toast.LENGTH_SHORT).show();
                                }else
                                {

                                    Toast.makeText(RegisterProfile.this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                }else {
                Toast.makeText(RegisterProfile.this, "" + phoneNumber + "already exists", Toast.LENGTH_SHORT).show();
            }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });



    }


}


