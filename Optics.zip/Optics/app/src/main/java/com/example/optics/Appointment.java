package com.example.optics;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import java.time.Year;
import java.util.Calendar;
import java.util.InputMismatchException;

public class Appointment extends AppCompatActivity {
    EditText BookingNumber,BookingMessage;
    EditText BookingDate,BookingTime;
    Button submitAppointment;
    DatePickerDialog datePickerDialog;
    TimePickerDialog timePickerDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        BookingNumber = (EditText)findViewById(R.id.bookingNumber);
        BookingMessage = (EditText)findViewById(R.id.bookingMessage);
        BookingDate = (EditText) findViewById(R.id.bookingDate);
        BookingTime = (EditText) findViewById(R.id.bookingTime);
        submitAppointment =(Button)findViewById(R.id.bookingSubmit);
        BookingDate.setInputType(InputType.TYPE_NULL);
        BookingTime.setInputType(InputType.TYPE_NULL);



        BookingDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar calendar = Calendar.getInstance();
               final int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                final int year = calendar.get(Calendar.YEAR);


                    datePickerDialog = new DatePickerDialog(Appointment.this, new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                            BookingDate.setText(dayOfMonth + "/" +( month + 1 )+ "/" + year );
                        }
                    } , year , month ,day);
                    datePickerDialog.show();


            }
        });

        BookingTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar time =Calendar.getInstance();

                final int hour = time.get(Calendar.HOUR_OF_DAY);
                int minutes = time.get(Calendar.MINUTE);

                timePickerDialog = new TimePickerDialog(Appointment.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        BookingTime.setText(hourOfDay + "/" + minute );
                    }
                },hour , minutes,false);
                timePickerDialog.show();
            }

        });







    }
}